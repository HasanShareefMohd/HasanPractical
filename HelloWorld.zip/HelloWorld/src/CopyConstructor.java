
public class CopyConstructor {
	private String name;
	private double marks;
	//cons
	CopyConstructor(String name, double marks){
		this.name=name;
		this.marks=marks;
	}
	
	CopyConstructor(CopyConstructor c){
		this.name=c.getName();
		this.marks=c.getMarks();
	}
	public String getName() {
return name;
	}
public void setName(String name) {
	this.name=name;
}

	double getMarks() {
		return marks;
	}
	public void setMarks(double marks) {
		this.marks=marks;

}
}
   
		
	
