
public class NestedIf {
	public static void main(String[] args) {
    String address = "hyd,kol";
    
    if(address.endsWith("hyd")){
    	if(address.endsWith("mum")){
    		System.out.println("your city is mum");
    	}else if(address.contains("newtown")){
    	System.out.println("your city is newtown");
        } else {
    	System.out.println(address.split(",")[0]);
        }
    	}else {
    	System.out.println("ur living in hyd");
    }
    	
    }
}

