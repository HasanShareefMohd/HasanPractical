
public class DoWhile {
	public static void main(String[] args) {
		int i=0;
		System.out.println("first 10 even num \n");
		do {
			System.out.println(i);
			i=i+2;
			
	}while(i<=10);

}


}
