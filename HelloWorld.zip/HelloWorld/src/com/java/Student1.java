package com.java;

//import practice.java.Address;
//import practice.java.Student;

public class Student1 {
	int id;
	String name;
	Address1 address;
	public Student1 (int id, String  name, Address1 address) {
		this.id=id;
		this.name=name;
		this.address=address;
	
		
		
	}
	void display() {
		System.out.println(id+" "+name);
		System.out.println(address.city+" "+address.state+" "+address.country);
		
	}
	public static void main (String[] args) {
	Address1 ad1= new Address1("gh","kk","ii");
	Address1 ad2= new Address1("ghgg","kknn","iin");
	Student1 st= new Student1(06,"hasan",ad1);
	Student1 st1= new Student1(06,"shareef",ad1);
	st.display();
	st1.display();
	}
	

}

