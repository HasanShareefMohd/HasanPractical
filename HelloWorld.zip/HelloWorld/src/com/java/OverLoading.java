package com.java;

public class OverLoading {
	static int add(int a, int b) 
	{
		return (a+b);
	}

		static int add1(int a, int b, int c)
		{
			return (a+b+c);
		}
		class overloading{
			public static void main(String[] args) {
				System.out.println(OverLoading.add(10,10 ));
				System.out.println(OverLoading.add1(10,10,10));
			}
		
	}
	
	

}
