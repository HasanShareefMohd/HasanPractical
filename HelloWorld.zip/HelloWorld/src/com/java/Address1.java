package com.java;

public class Address1 {
	String city, state, country;
	
	public Address1 (String city, String state, String country) {
		this.city=city;
		this.state=state;
		 this.country=country;
		
	}

}

