
public class IfElse {
	public static void main(String[] args) {
	
			int x=5;
			int y=3;
			if(x+y<10) {
				System.out.println("x + y is less than 10");	
			}else {
				System.out.println("x + y is greater than than 10");
				
		}
	}
	}


