
public class FinalVariable {
	int carspeed=60;
	void run() {
		carspeed=90;
	}
	public static void main(String[] args) {
		FinalVariable a= new FinalVariable();
		a.run();
		
		
		
	}

}
