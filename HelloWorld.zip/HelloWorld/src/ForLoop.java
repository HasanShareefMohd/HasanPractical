

	public class ForLoop {

public void myMethod()

{ System.out.println("Method"); }

{

System.out.println(" Instance Block");

}

public ForLoop()

{ System.out.println("Constructor "); }

static {

System.out.println("static block"); }

public static void main(String[] args) {

ForLoop c = new ForLoop();

c.ForLoop();

c.myMethod();

}

private void ForLoop() {
	// TODO Auto-generated method stub
	
}

}