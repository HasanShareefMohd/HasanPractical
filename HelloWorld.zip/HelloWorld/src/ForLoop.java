public class ForLoop {
	public static void main(String[] args) {
		int i=0;
		for(int j=1; j<10;j++) {
			i=i+j;
		}
		System.out.println("the sum of first 10 neutral num is");
	}

}
