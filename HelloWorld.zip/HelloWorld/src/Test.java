

public class Test {
	
			public static void main(String []args) {
				CopyConstructor c1=new CopyConstructor("hasan",440);
				CopyConstructor cloneo2=new CopyConstructor("shareef",520);
				c1.setName("ashu");
				System.out.println("student"+c1.getName());
				System.out.println("student"+cloneo2.getMarks());
			
		}
		    }
				


