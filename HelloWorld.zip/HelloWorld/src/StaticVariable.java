
public class StaticVariable {
	int rollno;
	String name;
	static String college="jits";
	//cons
	StaticVariable (int r, String n){
		rollno=r;
		name=n;
	}
	void display() {
		System.out.println(rollno+""+name+""+college);
		}
	public class TestStaticVariable{
		public static void main(String[] args) {
			StaticVariable s1=new StaticVariable (123,"hasan");
			StaticVariable s2=new StaticVariable (321,"shareef");
			s1.display();
			s2.display();
			
		}
	}
		
}
