
public class WhileLoop {
	public class DoWhile {
		public static void main(String[] args) {
			int i=0;
			System.out.println("first 10 even num \n");
			while(i<=10);{
				System.out.println(i);
				i=i+2;
			}
		}
	}
}
				
		

	


	


