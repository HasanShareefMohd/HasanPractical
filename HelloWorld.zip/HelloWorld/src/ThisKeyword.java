
public class ThisKeyword {
	int rollno;
	String name;
	float fee;
	
	ThisKeyword (int r, String n,float fee){
		this.rollno=r;
		this.name=n;
		this.fee=fee;
	}
	void display() {
		System.out.println(rollno+""+name+""+fee);
		}
	public class TestThisKeyword{
		public static void main(String[] args) {
			ThisKeyword s1=new ThisKeyword (123,"hasan",1000);
			ThisKeyword s2=new ThisKeyword (321,"shareef",2000);
			s1.display();
			s2.display();
			
		}
	}
		
}
