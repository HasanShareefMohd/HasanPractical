
public class StaticMetohod {
	int rollno;
	String name;
	static String college="jits";
	static void change() {
		college="jits";
	}
	//cons
	void StaticMethod (int r, String n){
		rollno=r;
		name=n;
	}
	void display() {
		System.out.println(rollno+""+name+""+college);
		}
	public class TestStaticMethod{
		public static void main(String[] args) {
			StaticMetohod s1=new StaticMetohod();
			StaticMetohod s2=new StaticMetohod();
			s1.display();
			s2.display();
			
		}
	}
		
}