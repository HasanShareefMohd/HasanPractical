
//import com.java.*;
class Inheritance {
   public void Hasan(){
      System.out.println("Hasan");
   }
}
class Display extends Inheritance{
   public void Shareef() {
      System.out.println("Shareef");
   }
}

