
public class Testing {
	
		public static void main(String[] arg) {
	     Display dis = new Display();
	     dis.Hasan();
	     dis.Shareef();
	  }
	}



