import java.util.Scanner;
class AgeWeight
{
	public static void main(String[] args)
	{
		//object of the Scanner class 
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter age : ");
		//reading a number from the user 
		int age = scan.nextInt();
		System.out.println("Enter weight : ");
		int weight = scan.nextInt();
		//checks the number less than equal to 25 and greater than equal to 60
		if(age>=25 && age<=60)
		{
			//checks the number is greater than equal to 48 
			if(weight>=48)
				System.out.println("He/she will donate blood");
			else
				System.out.println("he/she will donate blood");
		}
		else
		{
			System.out.println("He/she won't suitable age");
		}
	}
}