
public class SimpleIf {
	public static void main(String[] args) {
		int x=5;
		int y=3;
		if(x+y<10) {
			System.out.println("x + y is less than 10");
			
			
		}
	}
}
