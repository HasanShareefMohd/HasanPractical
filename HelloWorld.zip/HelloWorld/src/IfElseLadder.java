
public class IfElseLadder {
	public static void main(String[] args) {
		String name="ashu";
		if(name == "hasan") {
		System.out.println("name is hasan");
		}else if (name== "shareef") {
		System.out.println("name is shareef");
}else if (name== "areef") {
System.out.println("name is areef");
}else {
	System.out.println(name);
}
}
}
		
	


