import java.util.*;
class Voting
{
   public static void main(String args[])
   {
	 //object of the Scanner class
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter your Name: ");
    //reading a number from the user 
      String name=sc.nextLine();
      System.out.println("Enter your age: ");
    //reading a number from the user 
      int age=sc.nextInt();
    //checks the number less than equal to 18 and greater than equal to 100
      if((age>=18)&&(age<=100))
      {
          System.out.println("Congratulation "+name+", You are eligible for Voting");
      }
      else
      {
          System.out.println("Sorry "+name+", You are not eligible for voting");
      }      
  }
}

